package com.example.orbital_layoutfrontend;

import java.security.InvalidParameterException;
import java.util.ArrayList;

public class Player {
    String name;
    String teamName;
    ArrayList<Game> gameHistory;
    String position;
    String experienceLevel;

    /**
     * Constructor for a new player with no game history.
     * @param name
     * @param teamName
     * @param position
     * @param experienceLevel
     */
    public Player(String name, String teamName,
                  String position, String experienceLevel) throws InvalidParameterException {
        this.name = name;
        this.teamName = teamName;
        gameHistory = new ArrayList<>();

        if (position.equals("Handler") || position.equals("Cutter") ||
                position.equals("Beginner")) {
            this.position = position;
        } else {
            throw new InvalidParameterException();
        }

        if (experienceLevel.equals("Beginner") || experienceLevel.equals("Intermediate") ||
                experienceLevel.equals("Advanced") || experienceLevel.equals("Professional")) {
            this.experienceLevel = experienceLevel;
        } else {
            throw new InvalidParameterException("Invalid")
        }
    }
}
