package com.example.orbital_layoutfrontend;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class PlayerSelectPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_select_page);

        Spinner teamSelect = findViewById(R.id.team_spinner);
        String[] teams = new String[]{"Team 1", "Team 2", "Team 3"};   // query database to see which teams exist
        ArrayAdapter<String> teamAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, teams);
        teamSelect.setAdapter(teamAdapter);

        final Spinner playerSelect = findViewById(R.id.player_spinner);
        String[] players = new String[]{"Player 1", "Player 2", "Player 3"};   // query database to see which teams exist
        ArrayAdapter<String> playerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, players);
        playerSelect.setAdapter(playerAdapter);

        Button enterButton = findViewById(R.id.enter_button);
        Button newPlayerButton = findViewById(R.id.new_player_button);

        enterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(PlayerSelectPage.this, PlayerPage.class);
                Object player = playerSelect.getSelectedItem();
                i.putExtra("player", player.toString());
                startActivity(new Intent(PlayerSelectPage.this, PlayerPage.class));
            }
        });

        newPlayerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PlayerSelectPage.this, NewPlayerPage.class));
            }
        });
    }
}