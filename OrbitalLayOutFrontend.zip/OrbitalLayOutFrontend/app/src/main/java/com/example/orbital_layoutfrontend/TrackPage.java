package com.example.orbital_layoutfrontend;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class TrackPage extends AppCompatActivity {

    Player player;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_track_page);

        TextView playerTitle = findViewById(R.id.name_title);
        TextView teamTitle = findViewById(R.id.team_title);

        player = (Player) getIntent().getSerializableExtra("player");

        playerTitle.setText(player.getName());
        teamTitle.setText(player.getTeam());

        final int[] yourScore = {0};
        final int[] opponentScore = {0};

        Button endButton = findViewById(R.id.end_button);
        Button catchButton = findViewById(R.id.catch_button);
        Button passButton = findViewById(R.id.pass_button);
        Button cutButton = findViewById(R.id.cut_button);
        Button stallButton = findViewById(R.id.pass_button2);
        Button foulButton = findViewById(R.id.foul_button);
        Button turnoverButton = findViewById(R.id.turnover_button);
        Button pointScoredButton = findViewById(R.id.scored_button);

        TextView possessionText = findViewById(R.id.posession_text);
        TextView catchText = findViewById(R.id.catches_text);
        TextView passText = findViewById(R.id.passes_text);
        TextView cutText = findViewById(R.id.cuts_text);
        TextView scoreText = findViewById(R.id.score_text);

        endButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                player.addGame(
                    //TODO: MAKE THIS SMART INSTEAD OF JUST TAKING IN EVERYTHING AS SUCCESSFUL
                    new Game(Integer.parseInt(catchText.getText().toString()),
                            0, Integer.parseInt(passText.getText().toString()),
                            Integer.parseInt(passText.getText().toString()),
                            Integer.parseInt(cutText.getText().toString()),
                            Integer.parseInt(cutText.getText().toString()),
                            String.format("%d : %d", yourScore[0], opponentScore[0])));
                Intent i = new Intent(TrackPage.this, PlayerPage.class);
                i.putExtra("player", player);
                startActivity(i);
            }
        });

        catchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer catches = Integer.parseInt(catchText.getText().toString()) + 1;
                catchText.setText(catches.toString());
            }
        });

        passButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer passes = Integer.parseInt(passText.getText().toString()) + 1;
                passText.setText(passes.toString());
            }
        });

        cutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer cuts = Integer.parseInt(cutText.getText().toString()) + 1;
                cutText.setText(cuts.toString());
            }
        });

        turnoverButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String possession = possessionText.getText().toString();
                possessionText.setText(possession.equals("Offence") ? "Defence" : "Offence");
            }
        });

        pointScoredButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (possessionText.getText().toString().equals("Offence")) {
                    yourScore[0]++;
                } else {
                    opponentScore[0]++;
                }
                scoreText.setText(String.format("%d : %d", yourScore[0], opponentScore[0]));
            }
        });
    }
}