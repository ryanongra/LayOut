package com.example.orbital_layoutfrontend;

import android.os.Build;

import androidx.annotation.RequiresApi;

import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.io.Serializable;
import java.util.Objects;

public class Player implements Serializable {
    private String name;
    private String teamName;
    private ArrayList<Game> gameHistory;
    private String position;
    private String experienceLevel;

    /**
     * Constructor for a new player with no game history.
     * @param name
     * @param teamName
     * @param position
     * @param experienceLevel
     */
    public Player(String name, String teamName,
                  String position, String experienceLevel) throws InvalidParameterException {
        this.name = name;
        this.teamName = teamName;
        gameHistory = new ArrayList<>();

        if (position.equals("Handler") || position.equals("Cutter") ||
                position.equals("Beginner")) {
            this.position = position;
        } else {
            throw new InvalidParameterException("Invalid Position");
        }

        if (experienceLevel.equals("Beginner") || experienceLevel.equals("Intermediate") ||
                experienceLevel.equals("Advanced") || experienceLevel.equals("Professional")) {
            this.experienceLevel = experienceLevel;
        } else {
            throw new InvalidParameterException("Invalid Experience Level");
        }
    }

    public Player(String name, String teamName, ArrayList<Game> gameHistory,
                  String position, String experienceLevel) throws InvalidParameterException {
        this.name = name;
        this.teamName = teamName;
        this.gameHistory = gameHistory;

        if (position.equals("Handler") || position.equals("Cutter") ||
                position.equals("Beginner")) {
            this.position = position;
        } else {
            throw new InvalidParameterException("Invalid Position");
        }

        if (experienceLevel.equals("Beginner") || experienceLevel.equals("Intermediate") ||
                experienceLevel.equals("Advanced") || experienceLevel.equals("Professional")) {
            this.experienceLevel = experienceLevel;
        } else {
            throw new InvalidParameterException("Invalid Experience Level");
        }
    }

    public String getName() {
        return name;
    }

    public String getTeam() {
        return teamName;
    }

    public String toString() {
        return name;
    }

    public void addGame(Game newGame) {
        gameHistory.add(newGame);
    }

    public String getExperienceLevel() {
        return experienceLevel;
    }

    public Integer getGameCount() {
        return gameHistory.size();
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Player player = (Player) o;
        return Objects.equals(name, player.name);
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public int hashCode() {
        return Objects.hash(name);
    }

    public void changeTeam(String newTeam) {
        this.teamName = newTeam;
    }

    public void changeExperienceLevel(String experienceLevel) {
        if (experienceLevel.equals("Beginner") || experienceLevel.equals("Intermediate") ||
                experienceLevel.equals("Advanced") || experienceLevel.equals("Professional")) {
            this.experienceLevel = experienceLevel;
        } else {
            throw new InvalidParameterException("Invalid Experience Level");
        }
    }

    public ArrayList<Game> getGameHistory() {
        return gameHistory;
    }
}
