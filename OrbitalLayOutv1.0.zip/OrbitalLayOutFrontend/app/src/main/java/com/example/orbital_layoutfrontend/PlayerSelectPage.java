package com.example.orbital_layoutfrontend;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class PlayerSelectPage extends AppCompatActivity {

    Database myDatabase = new Database(true);

    ArrayList<Team> teams;
    ArrayList<Player> currPlayers;

    Team selectedTeam;
    Player selectedPlayer;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_select_page);

        Intent fromLastPage = getIntent();
        Player player = (Player) fromLastPage.getSerializableExtra("player");
        Boolean delete = (Boolean) fromLastPage.getSerializableExtra("delete");

        if (delete == null || !delete) {
            myDatabase.updatePlayer(player);
        } else {
            myDatabase.deletePlayer(player);
        }

        teams = myDatabase.getTeams();
        currPlayers = teams.get(0).getPlayers();

        selectedTeam = teams.get(0);
        selectedPlayer = selectedTeam.getPlayers().get(0);

        Spinner teamSelect = findViewById(R.id.team_spinner);
        ArrayAdapter<Team> teamAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, teams);
        teamSelect.setAdapter(teamAdapter);

        Spinner playerSelect = findViewById(R.id.player_spinner);
        ArrayAdapter<Player> playerAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, currPlayers);
        playerSelect.setAdapter(playerAdapter);

//        playerAdapter.clear();
//        playerAdapter.addAll(selectedTeam.getPlayers());

        teamSelect.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view,
                                       int position, long id) {
                Object item = adapterView.getItemAtPosition(position);
                selectedTeam = (Team) item;
                currPlayers = selectedTeam.getPlayers();
                playerAdapter.clear();
                playerAdapter.addAll(currPlayers);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        playerSelect.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view,
                                       int position, long id) {
                Object item = adapterView.getItemAtPosition(position);
                selectedPlayer = (Player) item;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        Button enterButton = findViewById(R.id.enter_button);
        Button newPlayerButton = findViewById(R.id.new_player_button);
        Button backButton = findViewById(R.id.back_button);

        enterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (teamSelect.getSelectedItem().equals(new Team("Select Team", null))) {
                    Toast.makeText(PlayerSelectPage.this, "Please select a Team and a Player", Toast.LENGTH_SHORT).show();
                } else {
                    Intent i = new Intent(PlayerSelectPage.this, PlayerPage.class);
                    i.putExtra("player", selectedPlayer);
                    startActivity(i);
                }
            }
        });

        newPlayerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PlayerSelectPage.this, NewPlayerPage.class));
            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PlayerSelectPage.this, MainActivity.class));
            }
        });
    }
}