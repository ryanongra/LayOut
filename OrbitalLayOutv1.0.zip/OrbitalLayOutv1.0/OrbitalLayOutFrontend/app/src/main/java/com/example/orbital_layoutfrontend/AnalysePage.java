package com.example.orbital_layoutfrontend;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

public class AnalysePage extends AppCompatActivity {

    public final String[] aspects = {"Catch rate",
                                     "Cut rate",
                                     "Pass completion rate",
                                     "Average points scored",
                                     "Average assists"};

    private Player player;

    private int noOfGames = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_analyse_page);

        player = (Player) getIntent().getSerializableExtra("player");

        TextView aspectName = findViewById(R.id.aspect_name_title);
        TextView valueTitle = findViewById(R.id.value_title);

        Spinner aspectSpinner = findViewById(R.id.aspect_spinner);
        ArrayAdapter<String> aspectAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, aspects);
        aspectSpinner.setAdapter(aspectAdapter);

        aspectSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view,
                                       int position, long id) {
                Object item = adapterView.getItemAtPosition(position);
                String selectedAspect = (String) item;
                aspectName.setText(selectedAspect);
                valueTitle.setText(updateValue(selectedAspect));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        Button backButton = findViewById(R.id.back_button);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(AnalysePage.this, PlayerPage.class);
                startActivity(i);
            }
        });
    }

    private String updateValue(String aspect) {
        return getStatText(aspect, noOfGames);
    }

    private String getStatText(String aspect, int noOfGames) {
        Player testPlayer = new Player("name", "team", "Handler", "Beginner");
        testPlayer.addGame(new Game(10, 5, 10, 5, 10, 5, "5 : 2"));

        switch (aspect) {
            case ("Catch rate"):
                return (Analyser.catchRate(testPlayer, noOfGames) + "%");
            case ("Cut rate"):
                return (Analyser.cutRate(testPlayer, noOfGames) + "%");
            case ("Pass completion rate"):
                return (Analyser.passRate(testPlayer, noOfGames) + "%");
            case ( "Average points scored") :
                return (Analyser.avePoints(testPlayer, noOfGames) + " pts");
            case ("Average assists") :
                return (Analyser.aveAssists(testPlayer, noOfGames));
            default:
                return "Aspect invalid";

        }
    }
}