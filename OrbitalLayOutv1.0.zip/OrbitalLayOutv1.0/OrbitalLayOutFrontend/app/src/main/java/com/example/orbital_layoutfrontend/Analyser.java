package com.example.orbital_layoutfrontend;

import java.util.ArrayList;

public class Analyser {

    public static String catchRate(Player player, int noOfGames) {
        Game[] games = new Game[noOfGames];
        Object[] gameHistory = player.getGameHistory().toArray();
        System.arraycopy(gameHistory, gameHistory.length - noOfGames, games, 0, noOfGames);

        Float totalCatches = 0.0f;
        Float totalFailed = 0.0f;
        for (Game game : games) {
                totalCatches += game.getCatches();
                totalFailed += game.getFailedCatches();
        }
        return  String.valueOf(((totalCatches - totalFailed) * 100) / totalCatches);
    }

    public static String cutRate(Player player, int noOfGames) {
        Game[] games = new Game[noOfGames];
        Object[] gameHistory = player.getGameHistory().toArray();
        System.arraycopy(gameHistory, gameHistory.length - noOfGames, games, 0, noOfGames);

        Float totalCuts = 0.0f;
        Float totalSuccessful = 0.0f;
        for (Game game : games) {
            totalCuts += game.getTotalCuts();
            totalSuccessful += game.getSuccessfulCuts();
        }
        return  String.valueOf((totalSuccessful * 100) / totalCuts);
    }

    public static String passRate(Player player, int noOfGames) {
        Game[] games = new Game[noOfGames];
        Object[] gameHistory = player.getGameHistory().toArray();
        System.arraycopy(gameHistory, gameHistory.length - noOfGames, games, 0, noOfGames);

        Float totalPass = 0.0f;
        Float totalSuccessful = 0.0f;
        for (Game game : games) {
            totalPass += game.getTotalPasses();
            totalSuccessful += game.getSuccessfulPasses();
        }
        return  String.valueOf((totalSuccessful * 100) / totalPass);
    }

    public static String avePoints(Player player, int noOfGames) {
        return "5";
    }

    public static String aveAssists(Player player, int noOfGames) {
        return "2";
    }

}
