package com.example.orbital_layoutfrontend;

import java.util.ArrayList;
import java.util.HashSet;

public class Database {

    private ArrayList<Team> teams = new ArrayList<>();
    private HashSet<Player> players = new HashSet<>();

    public Database(boolean hardcode) {
        if (hardcode) {
            ArrayList<Player> team1players = new ArrayList<>();
            ArrayList<Player> team2players = new ArrayList<>();
            ArrayList<Player> team3players = new ArrayList<>();

            Player player1A = new Player("Player 1A", "Team 1", "Handler", "Beginner");
            Player player1B = new Player("Player 1B", "Team 1", "Cutter", "Beginner");
            Player player2A = new Player("Player 2A", "Team 2", "Handler", "Intermediate");
            Player player2B = new Player("Player 2B", "Team 2", "Cutter", "Advanced");
            Player player3A = new Player("Player 3A", "Team 3", "Handler", "Professional");
            Player player3B = new Player("Player 3B", "Team 3", "Cutter", "Professional");

            team1players.add(player1A);
            team1players.add(player1B);
            team2players.add(player2A);
            team2players.add(player2B);
            team3players.add(player3A);
            team3players.add(player3B);

            players.add(player1A);
            players.add(player1B);
            players.add(player2A);
            players.add(player2B);
            players.add(player3A);
            players.add(player3B);

            Team team1 = new Team("Team 1", team1players);
            Team team2 = new Team("Team 2", team2players);
            Team team3 = new Team("Team 3", team3players);

            Player placeHolderPlayer = new Player("", "", "Handler", "Beginner");
            ArrayList<Player> placeHolderPlayers = new ArrayList<>();
            placeHolderPlayers.add(placeHolderPlayer);

            teams.add(new Team("Select Team", placeHolderPlayers));
            teams.add(team1);
            teams.add(team2);
            teams.add(team3);
        }
    }

    public ArrayList<Team> getTeams() {
        return teams;
    }

    public void updatePlayer(Player updatedPlayer) {
        if (players.contains(updatedPlayer)) {
            players.remove(updatedPlayer);
            players.add(updatedPlayer);
        } else {
            players.add(updatedPlayer);
        }
    }

    public void deletePlayer(Player player) {
        if (players.contains(player)) {
            players.remove(player);
        }
    }
}
