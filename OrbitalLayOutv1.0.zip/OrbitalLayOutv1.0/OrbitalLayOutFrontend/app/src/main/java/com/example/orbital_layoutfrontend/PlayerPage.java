package com.example.orbital_layoutfrontend;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import org.w3c.dom.Text;

public class PlayerPage extends AppCompatActivity {

    private final String[] experienceLevels = {"Beginner", "Intermediate", "Advanced", "Professional"};

    private final String[] teams = {"Team 1", "Team 2", "Team 3"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_page);

        TextView playerTitle = findViewById(R.id.player_name_title);
        TextView teamTitle = findViewById(R.id.player_team_title);
        TextView gamesText = findViewById(R.id.games_text);
        Spinner experienceSpinner = findViewById(R.id.experience_spinner);

        Intent fromLastPage = getIntent();
        Player player = (Player) fromLastPage.getSerializableExtra("player");

        playerTitle.setText(player.getName());
        teamTitle.setText(player.getTeam());
        gamesText.setText(player.getGameCount().toString());

        ArrayAdapter<String> experienceAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, experienceLevels);
        experienceSpinner.setAdapter(experienceAdapter);

        String experienceLevel = player.getExperienceLevel();
        int experienceLevelID = experienceLevel.equals("Beginner")
                ? 0
                : experienceLevel.equals("Intermediate")
                ? 1
                : experienceLevel.equals("Advanced")
                ? 2
                : 3;
        experienceSpinner.setSelection(experienceLevelID);

        Button trackButton = findViewById(R.id.track_button);
        Button analyseButton = findViewById(R.id.analyse_button);
        Button drillsButton = findViewById(R.id.drills_button);
        Button backButton = findViewById(R.id.back_button);
        Button deleteButton = findViewById(R.id.delete_button);
        Spinner changeTeam = findViewById(R.id.change_team_spinner);

        ArrayAdapter<String> teamAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, teams);
        changeTeam.setAdapter(teamAdapter);

        int teamID = player.getTeam().equals("Team 1")
                ? 0
                : player.getTeam().equals("Team 2")
                ? 1
                : player.getTeam().equals("Team 3")
                ? 2
                : 3;
        changeTeam.setSelection(teamID);

        changeTeam.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view,
                                       int position, long id) {
                Object item = adapterView.getItemAtPosition(position);
                String newTeam = (String) item;
                player.changeTeam(newTeam);

                teamTitle.setText(newTeam);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        trackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(PlayerPage.this, TrackPage.class);
                i.putExtra("player", player);
                startActivity(i);
            }
        });

        analyseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(PlayerPage.this, AnalysePage.class);
                i.putExtra("player", player);
                startActivity(i);
            }
        });

        drillsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PlayerPage.this, DrillsPage.class));
            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(PlayerPage.this, PlayerSelectPage.class);
                i.putExtra("player", player);
                i.putExtra("delete", false);
                startActivity(i);
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(PlayerPage.this, PlayerSelectPage.class);
                i.putExtra("player", player);
                i.putExtra("delete", true);
                startActivity(i);
            }
        });
    }
}