package com.example.orbital_layoutfrontend;

import android.os.Build;

import androidx.annotation.RequiresApi;

import com.example.orbital_layoutfrontend.Player;

import java.util.ArrayList;
import java.util.Objects;

public class Team {
    ArrayList<Player> players = new ArrayList<>();
    String name;

    public Team(String name, ArrayList<Player> players) {
        this.name = name;
        this.players = players;
    }

    public String getName() {
        return name;
    }

    public ArrayList<Player> getPlayers() {
        return players;
    }

    public String toString() {
        return name;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Team team = (Team) o;
        return Objects.equals(name, team.name);
    }
}
