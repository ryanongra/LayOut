package com.example.orbital_layoutfrontend.db;

public class UserDao {
}
