package com.example.orbital_layoutfrontend;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class GuidePage extends AppCompatActivity {

    final String guideMsg = "Peer Evaluation 1 note: \n" +
                            "Hello! Thank you for reviewing what we have done for Milestone 1! " +
                            "For the purpose of this app, please read below. Here we will " +
                            "explain what we have done do far amd what features we intend to add. \n" +
                            "\n" +
                            "Implemented features: \n" +
                            " - Player selection function* \n" +
                            " - Player page display* \n" +
                            " - Tracking function* \n" +
                            " - Analysis function* \n" +
                            " - Drill recommendation function* \n" +
                            "* do note that these functions have been implemented with placeholder " +
                            "teams and players because we have yet to implement the database " +
                            "and thus the data is not stored. \n" +
                            "\n" +
                            "Features to be implemented: \n" +
                            " - Database \n" +
                            " - New player function \n" +
                            " - Delete player function \n" +
                            " - Changeable time periods for analysis (buttons currently non-functional) \n" +
                            " - Embedded YouTube videos for Drill Recommendation page \n" +
                            "\n" +
                            "Welcome to Lay Out, your Ultimate Frisbee training companion! This " +
                            "page will take you through the features of this app and how to use " +
                            "it. \n" +
                            "\n" +
                            "You can TRACK a player during games in the TRACK PAGE by pressing the " +
                            "buttons based on the player's actions during a game. This app was " +
                            "designed to have a teammate or coach on the sideline monitoring and " +
                            "tracking a player who is on the field. \n" +
                            "\n" +
                            "Once you have tracked at least one game, you can ANALYSE that player's " +
                            "performance in the ANALYSE PAGE. This will give insights into a player's " +
                            "strengths and weaknesses, as well as their improvement across games. \n" +
                            "\n" +
                            "Finally, you can find recommended DRILLS in the DRILL PAGE which will " +
                            "help you work on weaknesses as identified by the analysis. \n" +
                            "\n" +
                            "We hope that this app will be able to take your Ultimate Frisbee game " +
                            "to the next level. Now go out there and make some sick plays!";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide_page);

        Button backButton = findViewById(R.id.back_button);
        TextView guideText = findViewById(R.id.guide_text);

        guideText.setText(guideMsg);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(GuidePage.this, MainActivity.class));
            }
        });

    }
}