package com.example.orbital_layoutfrontend;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Stack;


public class TrackPage extends AppCompatActivity {

    private Player player;
    private Stack<String> actionHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_track_page);

        TextView playerTitle = findViewById(R.id.name_title);
        TextView teamTitle = findViewById(R.id.team_title);

        player = (Player) getIntent().getSerializableExtra("player");
        actionHistory = new Stack<>();
        actionHistory.push("GAMESTART");

        playerTitle.setText(player.getName());
        teamTitle.setText(player.getTeam());

        final int[] yourScore = {0};
        final int[] opponentScore = {0};
        final int[] failedPasses = {0};
        final int[] successfulCuts = {0};
        final int[] drops = {0};

        Button endButton = findViewById(R.id.end_button);
        Button catchButton = findViewById(R.id.catch_button);
        Button passButton = findViewById(R.id.pass_button);
        Button cutButton = findViewById(R.id.cut_button);
        Button turnoverButton = findViewById(R.id.turnover_button);
        Button pointScoredButton = findViewById(R.id.scored_button);
        Button dropButton = findViewById(R.id.drop_button);
        Button successfulPassButton = findViewById(R.id.successfulPass_button);
        Button undoButton = findViewById(R.id.undo_button);

        TextView possessionText = findViewById(R.id.posession_text);
        TextView catchText = findViewById(R.id.catches_text);
        TextView passText = findViewById(R.id.passes_text);
        TextView cutText = findViewById(R.id.cuts_text);
        TextView scoreText = findViewById(R.id.score_text);

        endButton.setOnClickListener(new View.OnClickListener() {
            //TODO: MAKE SURE GAME SAVES CORRECTLY SO THAT ANALYZE CAN WORK!!

            @Override
            public void onClick(View v) {
                player.addGame(
                    //TODO: MAKE THIS SMART INSTEAD OF JUST TAKING IN EVERYTHING AS SUCCESSFUL
                    new Game(Integer.parseInt(catchText.getText().toString()),
                            0, Integer.parseInt(passText.getText().toString()),
                            Integer.parseInt(passText.getText().toString()),
                            Integer.parseInt(cutText.getText().toString()),
                            Integer.parseInt(cutText.getText().toString()),
                            String.format("%d : %d", yourScore[0], opponentScore[0])));
                Intent i = new Intent(TrackPage.this, PlayerPage.class);
                i.putExtra("player", player);
                startActivity(i);
            }
        });

        catchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer catches = Integer.parseInt(catchText.getText().toString()) + 1;
                catchText.setText(catches.toString());
                if (actionHistory.peek().equals("cut")) {
                    successfulCuts[0]++;
                }
                actionHistory.push("catch");
            }
        });

        passButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer passes = Integer.parseInt(passText.getText().toString()) + 1;
                passText.setText(passes.toString());
                actionHistory.push("pass");
            }
        });

        cutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer cuts = Integer.parseInt(cutText.getText().toString()) + 1;
                cutText.setText(cuts.toString());
                actionHistory.push("cut");
            }
        });

        dropButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drops[0]++;
                successfulCuts[0]++;
                actionHistory.push("drop");
            }
        });

        turnoverButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String possession = possessionText.getText().toString();
                possessionText.setText(possession.equals("Offence") ? "Defence" : "Offence");
                if (actionHistory.peek().equals("pass")) {
                    failedPasses[0]++;
                }
                actionHistory.push("turnover");
            }
        });

        successfulPassButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                actionHistory.push("successful pass");
            }
        });

        pointScoredButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (possessionText.getText().toString().equals("Offence")) {
                    yourScore[0]++;
                } else {
                    opponentScore[0]++;
                }
                scoreText.setText(String.format("%d : %d", yourScore[0], opponentScore[0]));
                actionHistory.push("point scored");
            }
        });

        undoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String previousAction = actionHistory.pop();
                if (previousAction.equals("cut")) {
                    Integer cuts = Integer.parseInt(cutText.getText().toString()) - 1;
                    cutText.setText(cuts.toString());
                } else if (previousAction.equals("catch")) {
                    Integer catches = Integer.parseInt(catchText.getText().toString()) - 1;
                    catchText.setText(catches.toString());
                    if (actionHistory.peek().equals("cut")) {
                        successfulCuts[0]--;
                    }
                } else if (previousAction.equals("drop")) {
                    drops[0]--;
                    successfulCuts[0]--;
                } else if (previousAction.equals("pass")) {
                    Integer passes = Integer.parseInt(passText.getText().toString()) - 1;
                    passText.setText(passes.toString());
                } else if (previousAction.equals("turnover")) {
                    String possession = possessionText.getText().toString();
                    possessionText.setText(possession.equals("Offence") ? "Defence" : "Offence");
                    if (actionHistory.peek().equals("pass")) {
                        failedPasses[0]--;
                    }
                } else if (previousAction.equals("point scored")) {
                    if (possessionText.getText().toString().equals("Offence")) {
                        yourScore[0]--;
                    } else {
                        opponentScore[0]--;
                    }
                    scoreText.setText(String.format("%d : %d", yourScore[0], opponentScore[0]));
                }
            }
        });
    }
}